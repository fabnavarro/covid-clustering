sphere.map<-function(theta)
{
x<-matrix(0,2,1)
x[1]<-sin(theta)
x[2]<-cos(theta)

return(x)
}


