volball<-function(r,d){ return(r^d*pi^(d/2)/gamma(d/2+1)) }

