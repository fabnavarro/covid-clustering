eva.lognormal<-function(t)
{

ans<-(2*pi)^(-1/2)*t^(-1)*exp(-(log(t))^2/2)

return(ans)
}

