###################################################################################
##' Adjusted Rand Index
##'
##' @description
##' This function computes the Adjusted Rand Index
##'
##' @param x vector defining a partition.
##' @param y vector defining a partition of whose length is equal to the length of x.
##'
##' @return numeric
##'
##' @references L. Hubert and P. Arabie (1985) Comparing Partitions, Journal of the Classification, 2, pp. 193-218.
##' @examples
##' x <- sample(1:2, 20, replace=TRUE)
##' y <- x
##' y[1:5] <- sample(1:2, 5, replace=TRUE)
##' ARI(x, y)
##' @export
##'
##'
ARI <- function (x, y){
  #### Tests on the input arguments
  if ((length(x) != length(y)))
    stop("The two partitions must be vectors of same length")

  ####

  ari <- 0
  if ((length(unique(x)) + length(unique(y))) == 2) ari <- 1
  conting <- table(x, y)
  a <- sum(choose(conting, 2))
  b <- sum(choose(rowSums(conting), 2)) - a
  c <- sum(choose(colSums(conting), 2)) - a
  d <- choose(sum(conting), 2) - a - b - c
  ari <- (a - (a + b) * (a + c)/(a + b + c + d))/((a + b +
                                                     a + c)/2 - (a + b) * (a + c)/(a + b + c + d))
  return(ari)
}


###################################################################################
##' Function of simulation
##'
##' @description
##' This function generates a sample according to the model defined in Section 4 in Cheam, et al. (2020)
##'
##' @param n number of observation
##' @param effect parameter defining the overlaps between clusters (denoted by varsigma in Cheam, et al. (2020))
##' @param gamma bivariate vector used for considering the covariate effects
##' @param delta vector of size n defining the shift of each observation
##' @return list()
##'
##' @references Amay SM Cheam, Marc Fredette, Matthieu Marbac, and Fabien Navarro (2020) Translation-invariant functional clustering on COVID-19 deaths adjusted on population risk factors, arXiv.
##' @examples
##' set.seed(123)
##' ech <- rclustfun(50)
##' # curves to cluster
##' ech$obs
##' # true cluster memberships
##' ech$z
##' # matrix of covarites
##' ech$covariates
##' # index (ech$covariates%in%gamma)
##' ech$index
##'
##' @export
##'
rclustfun <- function(n, effect=.3,  gamma=c(1,1)/sqrt(2), delta=sample(c(0, size/2), n, replace=TRUE, prob=c(.5,.5))){
  size=256
  z <- sample(1:3, n, replace=TRUE, prob = c(.5,.25,.25))
  covariates <- matrix(rnorm(n * 2), n, 2)
  index <- as.numeric(covariates%*%gamma)
  if (gamma[1]==0){
    nu <- rep(1, n)
  }else{
    nu <- (1 - effect + effect*(index**2) )
  }
  fbase <- sin(2.5 * pi * (1:(2*size))/size)
  fbasebis <- sin((2.5-effect) * pi * (1:(2*size))/size)
  fbase <- fbase * (fbase>0)
  fbasebis <- fbasebis * (fbasebis>0)
  r <- rbind(fbase,
             (1+effect) * fbase,
             (1 + c(rep(0, size/2), rep(effect, size * 3/2))) * fbasebis)
  obs <- matrix(NA, n, size)
  probapost <- matrix(NA, n, 3)
  for (i in 1:n){
    epsilon <- rep(NA, ncol(r))
    epsilon[1] <- rnorm(1, sd = 0.2)
    for (j in 2:length(epsilon)) epsilon[j] <- rnorm(1) * (0.2  + 0.2 * epsilon[j-1]**2)
    tim <- (1:size) + delta[i]
    coeff <- r[z[i], tim] + epsilon[tim]
    for (k in 1:3){
      probapost[i,k] <- sum(dnorm(coeff, r[k,tim], sd = .2, log=TRUE))
    }
    obs[i,] <- coeff * nu[i]
  }
  obs <- obs
  zhat <- apply(probapost, 1, which.max)
  list(obs=obs, z=z, covariates=covariates, index=index)
}
