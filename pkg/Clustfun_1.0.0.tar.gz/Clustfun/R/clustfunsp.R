
##' Functional clustering
##'
##' Model-based clustering of functional data with feature extraction based on translation invariante wavelets and possibility to consider external covariates.
##'
##' \tabular{ll}{
##'   Package: \tab clustfunsp\cr
##'   Type: \tab Package\cr
##'   Version: \tab 1.0.0\cr
##'   Date: \tab 2020-12-16\cr
##'   License: \tab GPL-3\cr
##'   LazyLoad: \tab yes\cr
##' }
##'
##'
##' @name Clustfun-package
##' @aliases Clustfun
##' @rdname Clustfun-package
##' @docType package
##' @keywords package
##' @import nnet
##' @import rwavelet
##' @import mixtools
##' @import regpro
##' @import expm
##' @importFrom stats dnorm rnorm
##' @references Amay SM Cheam, Marc Fredette, Matthieu Marbac and Fabien Navarro (2020) Translation-invariant functional clustering on COVID-19 deaths adjusted on population risk factors, arXiv.
NULL

##' Clustering function
##'
##' @description
##' Clustering of functional data based on wavelet feature extraction where external covariates can be included
##'
##' @param obs matrix of the observations (one row per curve)
##' @param Kvals numbers of clusters (must be a numeric)
##' @param type to specify the type of wavelets ("PO": orthogonal or "TI": translation invariante)
##' @param covariates  matrix of the covariates (same number of rows that obs, all the variables must be numeric).
##'
##' @return Returns a list containing the feature extraction (wave), the regression estimators (reg) and the clustering output (clustering, list, one element per number of clusters)
##'
##' @references Amay SM Cheam, Marc Fredette, Matthieu Marbac, and Fabien Navarro (2020) Translation-invariant functional clustering on COVID-19 deaths adjusted on population risk factors, arXiv.
##'
##' # data generation (50 time-shited curves arisen from three clusters with covariate effect)
##' set.seed(123)
##' ech <- rclustfun(50)
##' # clustering
##' out <- clustfun(ech$obs, Kvals=3, covariates=ech$covariates)
##' # estimated partition
##' out$clustering[[1]]$zhat
##' # adjusted rand index between the estimated and the true partition
##' ARI(ech$z, out$clustering[[1]]$zhat)
##' # plot of the estimated index and estimated covariate effect
##' plot(out$reg$index, out$reg$effect)
##'
##' @export
clustfun <- function(obs,
                       Kvals,
                       type = "TI",
                       covariates = NULL){
  # wavelet decomposition
  out <- list(wave = waveletsDecomposition(type,
                                           obs,
                                           MakeONFilter('Symmlet', 6),
                                           floor(log2(ncol(obs))),
                                           FALSE,
                                           TRUE))
  # single index regression if covariates occur
  out <- regression(out, covariates)
  # NP clustering
  out$clustering <- lapply(Kvals, clustering, out=out, band=nrow(obs)**(-1/5))
  # tunning the clustering results
  for (k in 1:length(Kvals)){
    if (Kvals[k]!=1){
      ord <- 0
      if (is.null(covariates)){
        ord <- order( as.numeric(t(out$clustering[[k]]$weights) %*% (rowSums(obs))) / colSums(out$clustering[[k]]$weights))
      }else{
        ord <- order( as.numeric(t(out$clustering[[k]]$weights) %*% (rowSums(obs)/exp(out$reg$m))) / colSums(out$clustering[[k]]$weights))
      }
      out$clustering[[k]]$weights <- out$clustering[[k]]$weights[,ord]
      out$clustering[[k]]$post <- out$clustering[[k]]$post[,ord]
      out$clustering[[k]]$coeff <- out$clustering[[k]]$coeff[ord]
      out$clustering[[k]]$zhat <-  apply(out$clustering[[k]]$post, 1, which.max)
      rownames(out$clustering[[k]]$post) <- names( out$clustering[[k]]$zhat) <- rownames(obs)

    }
  }
  # results
  out
}
