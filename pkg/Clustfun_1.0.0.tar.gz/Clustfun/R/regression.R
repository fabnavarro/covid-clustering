regression <- function(out, covariates){
  out$obstocluster <- log(t(sqrt(out$wave$contj)))
  if (!is.null(covariates)){
    covariates <- scale(covariates)
    tmp <- scale(log(sqrt(t(out$wave$contj))), scale = F)
    out$reg <- list()
    cv <- covariates
    target <- tmp[,1]
    for (j in 2:ncol(out$obstocluster)){
      cv <- rbind(cv, covariates)
      target <- c(target, tmp[,j])
    }
    out$reg$siparam <- single.index(cv, target, h = length(target)**(-1/5))
    out$reg$index <- as.numeric(covariates %*%out$reg$siparam)
    out$reg$m <- sapply(out$reg$index, function(u) locfct(u, rep(out$reg$index, ncol(tmp)), target))
    for (j in 1:ncol(out$obstocluster)){
      out$obstocluster[,j] <- tmp[,j] - out$reg$m
    }
    effect <- exp(out$reg$m)
    out$reg$effect <- effect - mean(effect) + 1
  }
  out$obstocluster <- scale(out$obstocluster)

  out
}

# regression <- function(out, covariates, band, backward, pvalback){
#   out$obstocluster <- log(t(out$wave$contj))
#   if (!is.null(covariates)){
#     tmp <- scale(log(sqrt(t(out$wave$contj))), scale = F)
#     out$reg <- list()
#     cv <- covariates
#     target <- tmp[,1]
#     for (j in 2:ncol(out$obstocluster)){
#       cv <- rbind(cv, covariates)
#       target <- c(target, tmp[,j])
#     }
#     if (ncol(cv)==2) backward=FALSE
#     if (backward){
#       out$reg$siparam <- backwardprocedure(cv, target, pvalback)
#     }else{
#       out$reg$siparam <- single.index(cv, target)
#     }
#     out$reg$index <- as.numeric(covariates %*%out$reg$siparam)
#     out$reg$m <- sapply(out$reg$index, function(u) locfct(u, rep(out$reg$index, ncol(tmp)), target))
#     #out$reg$m <- sapply(1:nrow(out$reg$index), function(i) loclin(out$reg$index[i,], out$reg$index, out$obstocluster[,j], h=band))
#     for (j in 1:ncol(out$obstocluster)){
#       out$obstocluster[,j] <- out$obstocluster[,j] - out$reg$m
#     }
#   }
#   out$obstocluster <- scale(out$obstocluster)
#   out
# }

#
# backwardprocedure <- function(cv, target, pvalback){
#   d <- ncol(cv)
#   n <- length(target)
#   nonzeroparam <- param <- as.numeric(single.index(cv, target))
#   pvalue <- elspsi(cv, NULL, target, beta1 = NULL, beta2 = param)$pvalue
#   keep <- 1:d
#   while (pvalue>pvalback){
#     keepcand <- keep[-which.min(abs(nonzeroparam))]
#     nonzeroparam <- as.numeric(single.index(cv[,keepcand], target))
#     paramcand <- c(nonzeroparam, rep(0, d-length(keepcand)))
#     droped <- (1:d)[-keepcand]
#     pvalue <- elspsi(cv[,c(keepcand, droped)], NULL, target, beta1 = NULL, beta2 = param)$pvalue
#     if (pvalue>pvalback){
#       param <- paramcand
#       keep <- keepcand
#       if (length(keep)==2) break
#     }
#   }
#   param
# }


locfct <- function(eval, index, Ystar){
  u <- dnorm(index, eval, sd = length(Ystar)**(-1/5))
  sum(u*Ystar)/sum(u)
}

