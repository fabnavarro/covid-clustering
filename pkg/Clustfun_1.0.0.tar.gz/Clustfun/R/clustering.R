clustering <- function(out, K, band){
  out$clustering <- npMSL(out$obstocluster,
                          mu0=K,
                          bw=band, verb = FALSE)
  list(weights=out$clustering$posteriors,
       band=band,
       coeff=out$clustering$lambdahat,
       logSmoothlike=out$clustering$loglik[length(out$clustering$loglik)],
       post=out$clustering$posteriors,
       zhat=apply(out$clustering$posteriors, 1, which.max)
  )
}

#
# computeW <- function(x, h=nrow(x)**(-1/5))
#   lapply(1:ncol(x), function(j) sapply(x[,j], function(u) dnorm(u, x[,j], sqrt(2) * h)))
#
# computeRj <- function(W){
#   Wroot <- lapply(W, sqrtm)
#   A <- (Wroot[[2]] %*% Wroot[[1]]) / nrow(W[[1]])
#   vpsquare <- eigen(t(Conj(A))%*%A)$values
#   vpsquare[vpsquare<0] <- 0
#   sqrt(sum(vpsquare) - cumsum(vpsquare) + vpsquare)
# }
#
# myobjTau <- function(tau, delta, N, L, sigma2)
#   ( -tau * log(1 + tau * L / sigma2) /L  + log(1 + tau / L - (sigma2 / (L**2)) * log(1 + tau * L /sigma2) ) - log(delta / 2)/N)**2
#
# computeTau <- function(W, bsup, delta=0.05){
#   n <- nrow(W[[1]])
#   THSsquare <- matrix(diag(W[[1]])*diag(W[[2]]), n, n, byrow=F) + matrix(diag(W[[1]])*diag(W[[2]]), n, n, byrow=T) - 2 * W[[1]] * W[[2]]
#   sigma2hat <- sum(THSsquare) / (2 * n*(n-1))
#   Lhat <- max(sqrt(THSsquare))
#   optimize(myobjTau, interval = c(0, bsup + .2), delta=delta, N=n, L=Lhat, sigma2=sigma2hat)$minimum
# }

# giveCompoNumber <- function(obs){
#   W <- computeW(obs)
#   Rj <- computeRj(W)
#   tau <- computeTau(W, bsup=Rj[1])
#   sum(Rj >= tau)
# }
