waveletsDecomposition <- function(type, obs, qmf, scale, iwt, alpha)
  switch(type,
         TI = waveletsTI(obs, qmf, scale, iwt, alpha),
         PO = waveletsPO(obs, qmf, scale, iwt, alpha))

waveletsPO <- function(obs, qmf, scale, iwt, alpha){
  obs <- t(obs)
  J <- floor(log2(nrow(obs)))
  df <- obs[1:2^J,]
  n <- nrow(df)
  j0 <- 0
  norm2vec <- function(x){sum(x^2)}
  # apply Forward/Inverse Wavelet Transform
  # (Periodic Orthogonal case)
  wc <- apply(df,2,FWT_PO,j0,qmf)
  # Linear estimator collection
  wci <- array(0,dim=dim(wc))
  wci[1:(2^scale),] <- wc[1:(2^scale),]
  if(iwt){wcr <- apply(wci, 2, IWT_PO, j0, qmf)}
  # Energy criteria
  z_i <- wci[-1,]
  contj <- relj <- matrix(0, ncol = ncol(z_i), nrow = scale)
  if(alpha){contj[1,] <- z_i[1,]^2 + wc[1,]^2}
  if(!alpha){contj[1,] <- z_i[1,]^2}
  for (j in 2:scale){
    ind <- (2^(j-1)):(2^j-1)
    contj[j,] <- apply(z_i[ind,],2, norm2vec)
  }
  if(iwt){
    list(contj = contj,
         wci = wci,
         wc = wc,
         wcr = wcr)}
  if(!iwt){
    list(contj = contj,
         wci = wci,
         wc = wc)}
}

waveletsTI <- function(obs, qmf, scale, iwt, alpha){
  obs <- t(obs)
  J <- floor(log2(nrow(obs)))
  df <- obs[1:2^J,]
  n <- nrow(df)
  j0 <- 0
  norm2vec <- function(x){sum(x^2)}
  wc <- apply(df, 2, FWT_TI, j0, qmf)
  wci <- array(0, dim=dim(wc))
  for (jj in 1:(scale+1)){
    ind <- ((jj-1)*n+1):(n*jj)
    wci[ind,] <- wc[ind,]
  }
  wctmp <- wci
  if(iwt){
    # reshape wci to match TItable for inversion
    wci <- lapply(1:ncol(wci),
                  function(i){array(wci[,i], dim=c(n,J+1))})
    # go back to original domain by inversion
    wcr <- array(unlist(lapply(wci,IWT_TI,qmf)),dim=dim(df))
  }
  if (alpha){
    z_i <- wctmp
    contj <- relj <- matrix(0,ncol = ncol(z_i),
                            nrow = scale+1)
    for (j in 1:(scale+1)){
      ind <- ((j-1)*n+1):(n*j)
      contj[j,] <- apply(z_i[ind,], 2, norm2vec)
    }
  }
  if (!alpha){
    z_i <- wctmp[-c(1:n),]
    contj <- relj <- matrix(0,ncol = ncol(z_i),
                            nrow = scale)
    for (j in 1:scale){
      ind <- ((j-1)*n+1):(n*j)
      contj[j,] <- apply(z_i[ind,], 2, norm2vec)
    }
  }
  if(iwt){
    list(contj = contj,
         wci = wci,
         wc = wc,
         wcr = wcr)}
  if(!iwt){
    list(contj = contj,
         wci = wci,
         wc = wc)}
}
# waveletsDecomposition <- function(type, obs, qmf, scale, iwt, alpha)
#   switch(type,
#          TI = waveletsTI(obs, qmf, scale, iwt, alpha),
#          PO = waveletsPO(obs, qmf, scale, iwt, alpha))
#
# waveletsPO <- function(obs, qmf, scale, iwt, alpha){
#   obs <- t(obs)
#   J <- floor(log2(nrow(obs)))
#   df <- obs[1:2^J,]
#   n <- nrow(df)
#   j0 <- 0
#   norm2vec <- function(x){sum(x^2)}
#   # apply Forward/Inverse Wavelet Transform
#   # (Periodic Orthogonal case)
#   wc <- apply(df,2,FWT_PO,j0,qmf)
#   # Linear estimator collection
#   wci <- array(0,dim=dim(wc))
#   wci[1:(2^scale),] <- wc[1:(2^scale),]
#   if(iwt){wcr <- apply(wci, 2, IWT_PO, j0, qmf)}
#   # Energy criteria
#   z_i <- wci[-1,]
#   contj <- relj <- matrix(0, ncol = ncol(z_i), nrow = scale)
#   if(alpha){contj[1,] <- z_i[1,]^2 + wc[1,]^2}
#   if(!alpha){contj[1,] <- z_i[1,]^2}
#   for (j in 2:scale){
#     ind <- (2^(j-1)):(2^j-1)
#     contj[j,] <- apply(z_i[ind,],2, norm2vec)
#   }
#   if(iwt){
#     list(contj = contj,
#          wci = wci,
#          wc = wc,
#          wcr = wcr)}
#   if(!iwt){
#     list(contj = contj,
#          wci = wci,
#          wc = wc)}
# }
#
# waveletsTI <- function(obs, qmf, scale, iwt, alpha){
#   obs <- t(obs)
#   J <- floor(log2(nrow(obs)))
#   df <- obs[1:2^J,]
#   n <- nrow(df)
#   j0 <- 0
#   norm2vec <- function(x){sum(x^2)}
#   wc <- apply(df, 2, FWT_TI, j0, qmf)
#   wci <- array(0, dim=dim(wc))
#   for (jj in 1:(scale+1)){
#     ind <- ((jj-1)*n+1):(n*jj)
#     wci[ind,] <- wc[ind,]
#   }
#   wctmp <- wci
#   if(iwt){
#     # reshape wci to match TItable for inversion
#     wci <- lapply(1:ncol(wci),
#                   function(i){array(wci[,i], dim=c(n,J+1))})
#     # go back to original domain by inversion
#     wcr <- array(unlist(lapply(wci,IWT_TI,qmf)),dim=dim(df))
#   }
#   if (alpha){
#     z_i <- wctmp
#     #- Version assuming two different
#     #- scales for alpha_0^T and beta_0^T
#     # contj <- matrix(0,ncol = ncol(z_i),
#     #                         nrow = scale+1)
#     # for (j in 1:(scale+1)){
#     #   ind <- ((j-1)*n+1):(n*j)
#     #   contj[j,] <- apply(z_i[ind,], 2, norm2vec)
#     # }
#     # contj <- contj/(2^(c(J,1:scale)))
#     #- Version with concatenation of scale j=0
#     contj <- matrix(0,ncol = ncol(z_i),
#                     nrow = scale)
#     contj[1,] <- apply(z_i[1:n,],2,norm2vec)/n +
#       apply(z_i[(n+1):(2*n),],2,norm2vec)/2
#     for (j in 3:(scale+1)){
#       ind <- ((j-1)*n+1):(n*j)
#       contj[j-1,] <- apply(z_i[ind,], 2, norm2vec)
#     }
#     # normalization to preserve energy
#     contj <- contj/(2^(c(0,2:(scale))))
#   }
#   if (!alpha){
#     z_i <- wctmp[-c(1:n),]
#     contj <- matrix(0,ncol = ncol(z_i),
#                     nrow = scale)
#     for (j in 1:scale){
#       ind <- ((j-1)*n+1):(n*j)
#       contj[j,] <- apply(z_i[ind,], 2, norm2vec)
#     }
#     contj <- contj/(2^(1:scale))
#   }
#   if(iwt){
#     list(contj = contj,
#          wci = wci,
#          wc = wc,
#          wcr = wcr)}
#   if(!iwt){
#     list(contj = contj,
#          wci = wci,
#          wc = wc)}
# }
